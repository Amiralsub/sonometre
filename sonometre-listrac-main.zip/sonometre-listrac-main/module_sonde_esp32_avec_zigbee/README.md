# Sonometre Listrac

| Supported Targets | ESP32-H2 |
| ----------------- | -------- | 

## ESP-IDF and VS-code

To use our code we need ESP-IDF. It is Espressif's IoT framwork used to program ESP chips. We have used ESP-IDF in combination with VS Code bur **that is not required**. The fact that there was an ESP-IDF extension for VS Code made our life easier and we knew VS Code as it is the IDE that is used at our school. We will explain the installation process here. 

### Installation within Orange

On Orange PC we need to use either `C:\Applications` or `C:\My Program Files` but there are spaces in the name of the second so it makes using it complicated. We recommand to install every needed program in `C:\Applications`. We would like to remind you to use Adminute to obtain temporary admin right to do every installation.  

### VS Code

VS Code is quite powerfull because of it's huge community. It is Microsoft own IDE so it works well with github wich is possessed by Microsoft to. You can download the installer [here](https://code.visualstudio.com/download). Then follow the installation process and don't forget to install it in `C:\Applications`. 

### ESP-IDF 

Espressif IoT Development Framework (ESP-IDF) is made and maintained by Espressif, the company that created the ESP. You can access the procedure to install it with VS Code [here](https://idf.espressif.com/). We recommand to stop the proxy and to install ESP-IDF using a mobil connexion. We have had issues with the framwork having recognized and memorized the proxy but beeing unable to be identified and not beeing able to access internet wich is needed at some point. Note that we are using an ESP32-H2 and the version **5.2.2** of ESP-IDF.

### Materiel needed

- A ESP32-H2 DevKit  
- A USB C cable 
- A Zigbee coordinator that deploys a network

## The project


### Architecture of the project 

In the folder named `\module_sonde_esp32_avec_zigbee\` you can find : 

- `sdkconfig` and `sdkconfig.defaults` wich are config files for the project. 
- `CMakeLists.txt` wich is a config file for the compilation (or build) of the project. 
- `partition.csv` wich is used to define custom partitions in the ESP memory for the zigbee stack to work correcly. 
- `main\` wich is the folder that contains the code of our program. It contains some files : 
- - `CMakeLists.txt` wich is a config file for the compilation (or build) of the project. 
  - `idf_component.yml` wich is a config file that manages dependencies. 
  - `sonometre_main.c` and `sonometre_main.h` are the source and header files. 

### The code 

The code is separated in three sections :
1) The sensors :
   
In the sensor section there is a task with a setup for each sensor and a common loop where every sensor is called for a measurement every second. The sound level sensor takes 10 measures over tàhe course of a seconde and compute the mean to smooth the variations. 

2) The zigbee :
   
   In the zigbee section there are a few functions. First there are some callbacks used when the zigbee stack sends a specific signal to the application. Then there is the `app_signal_handler` that receives a signal from the zigbee stack and deals with it. Here there are only some signal that are treated but there are dozens of theme so some case may fall under the default condition. It may be interesting to deal with those cases if it happens to you. We've dealt with all the cases we've encountered. The `zb_action_handler` works as the `app_signal_handler` do. 
   
   The `esp_zb_task` creates an endpoint for each sensor. In each endpoint it creates an analog input cluster wich can contain an unique value. All the endpoints are coontained in a zigbee 'device'. 
   The `esp_zb_value_task` changes the values contained in the different endpoints with the latest value available every second. 

Here is the configuration of the IDE and of the project. 

### Downloading and configuring our project

Once you have installed VS Code and ESP-IDF you can download or clone the project on gitlab. Then open the folder `\sonometre-listrac\module_sonde_esp32_avec_zigbee` with VS Code and you should obtain this type of window : 


![VS Code with ESP-IDF](/VS_code.PNG "Here is what you should see when opening the project's folder")


There you need to configure the extension to work as wanted. 

#### Configuration of the extension 

The extension is responsible for the icons at the bottom of VS Code. From left to right here are the tings you need to do : 
- You need to click where there is COM6 written in the screenshot. It should open at the top of the window a list of all the USB devices connected to your computer. Please select the one that correspond to the ESP32 you want to use. 
- The icon of a CPU correspond to the 'target'. It's the type of chip you are using, here it says esp32-h2 wich is correct but if it doesn't please click and then select the right chip at the top of the window. 
- The star icon represent the methode used to flash the project on the esp32. Here we use UART wich correspond to the UART USB C port on the USB. 

Now the extension is set up. You need to verify those settings each time you want to use an ESP32 chip. 

#### Configuration of the board

The next step is to set up the settings we want for the project. There is a default config file ( `\sdkconfig.defaults` ) in the project but there may be some adjustements you wanna do. For example if you don't use the GPIO 4 and 5 for SDA and SCL. Those settings are accessible in the menuconfig. To access the menuconfig use the button that represents a gear. There you can see all the settings that you can modify. Check the Zigbee, the I2C and the panic settings, those are the one we have used and modified for now. 

The last step before building and flashing the program into the board is erasing the flash memory of the board. To do it you need to open an ESP-IDF terminal with the terminal icon at the bottom : `>_` and type `idf.py -p PORT erase-flash` with `PORT` beeing the USB port wich is connected to the ESP32 (COM6 in the previous screenshot). 


### Build flash and monitor

- To build you can use the wrench icon at the top.
- To flash you can use the lightning icon at the top. 
- To monitor you can use the screen icon at the top. 

Or you can do the three steps in one click using the flamme icon. 

## Your project 

This section is meant for people wanting to modify the project.  I consider that you are familar with VS Code and the ESP-IDF extension if you want to do this. 

If you want to modify the project here are some ideas :
- You can add sensors
- You can add screen or leds to indicate the level of one or many values directly next to the ESP32
- You can basicly do whatever you want

To add a sensor you need to : 
- Import the librairy of the sensor
- Add the sensor to the measurement task 
- Modify the `esp_zb_task` to add an endpoint containing an analog input cluster containing a present value attribut in wich you'll store the measured value. 
- Modify the `esp_zb_value_task` to make periodic adjustement to the value store in your new attribut. 

Feel free to modify this as you want and enjoy. 


## Authors 

For ESP related questions :
[Cédric Toulotte](https://github.com/Pl0uf-tlt) 

For web related questions (Node.js, MariaDB, Websockets) : 
[Gwenn](https://www.youtube.com/watch?v=dQw4w9WgXcQ)
