/*
 * SPDX-FileCopyrightText: 2021-2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 *
 * Zigbee customized client Example
 *
 * This example code is in the Public Domain (or CC0 licensed, at your option.)
 *
 * Unless required by applicable law or agreed to in writing, this
 * software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, either express or implied.
 */

#include "esp_zigbee_core.h"

/* Zigbee configuration */
#define INSTALLCODE_POLICY_ENABLE       false    /* enable the install code policy for security */
#define ED_AGING_TIMEOUT                ESP_ZB_ED_AGING_TIMEOUT_64MIN
#define ED_KEEP_ALIVE                   3000    /* 3000 millisecond */
#define ANALOG_INPUT_ENDPOINT_TEMP        1           /* esp analog input temperature device endpoint */
#define ANALOG_INPUT_ENDPOINT_HUM         2           /* esp analog input humidity device endpoint */
#define ANALOG_INPUT_ENDPOINT_VOC         3           /* esp analog input voc device endpoint */
#define ANALOG_INPUT_ENDPOINT_CO2         4           /* esp analog input co2 device endpoint */
#define ANALOG_INPUT_ENDPOINT_VOL         5           /* esp analog input volume device endpoint */
#define ANALOG_INPUT_ENDPOINT_PM1_0       6           /* esp analog input pm1.0 device endpoint */
#define ANALOG_INPUT_ENDPOINT_PM2_5       7           /* esp analog input pm2.5 device endpoint */
#define ANALOG_INPUT_ENDPOINT_PM4_0       8           /* esp analog input pm4.0 device endpoint */
#define ANALOG_INPUT_ENDPOINT_PM10_0      9           /* esp analog input pm10.0 device endpoint */
#define ESP_ZB_PRIMARY_CHANNEL_MASK     (1l << 20)    /* Zigbee primary channel mask use in the example */
#define ESP_ZB_SECONDARY_CHANNEL_MASK   (0x07FFF800)  /* Zigbee primary channel mask use in the example */

#define ESP_ZB_ZED_CONFIG()                                         \
    {                                                               \
        .esp_zb_role = ESP_ZB_DEVICE_TYPE_ED,                       \
        .install_code_policy = INSTALLCODE_POLICY_ENABLE,           \
        .nwk_cfg.zed_cfg = {                                        \
            .ed_timeout = ED_AGING_TIMEOUT,                         \
            .keep_alive = ED_KEEP_ALIVE,                            \
        },                                                          \
    }                                                               

#define ESP_ZB_ZR_CONFIG()                                          \
    {                                                               \
        .esp_zb_role = ESP_ZB_DEVICE_TYPE_ROUTER,                   \
        .install_code_policy = INSTALLCODE_POLICY_ENABLE,           \
        .nwk_cfg.zczr_cfg = {                                       \
            .max_children = 32,                                     \
        }                                                           \
    }

#define ESP_ZB_DEFAULT_RADIO_CONFIG()                           \
    {                                                           \
        .radio_mode = ZB_RADIO_MODE_NATIVE,                     \
    }

#define ESP_ZB_DEFAULT_HOST_CONFIG()                            \
    {                                                           \
        .host_connection_mode = ZB_HOST_CONNECTION_MODE_NONE,   \
    }
